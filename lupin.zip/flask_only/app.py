from flask import Flask, render_template, request, redirect, url_for

app = Flask(__name__)

wrestlers = [
    {'id': 1, 'name': 'John Cena', 'signature_move': 'Attitude Adjustment'},
    {'id': 2, 'name': 'The Undertaker', 'signature_move': 'Tombstone Piledriver'},
    {'id': 3, 'name': 'Stone Cold Steve Austin', 'signature_move': 'Stone Cold Stunner'},
]

# Homepage - List all wrestlers
@app.route('/',methods=['GET'])
def index():
    return render_template('index.html', wrestlers=wrestlers)

# Create a new wrestler
@app.route('/create', methods=['GET', 'POST'])
def create():
    if request.method == 'POST':
        new_id = max(w['id'] for w in wrestlers) + 1 if wrestlers else 1
        name = request.form['name']
        signature_move = request.form['signature_move']
        wrestlers.append({'id': new_id, 'name': name, 'signature_move': signature_move})
        return redirect(url_for('index'))
    return render_template('create.html')

# Update a wrestler's details
@app.route('/update/<int:wrestler_id>', methods=['GET', 'POST'])
def update(wrestler_id):
    wrestler = next((w for w in wrestlers if w['id'] == wrestler_id), None)
    if not wrestler:
        return "Wrestler not found", 404

    if request.method == 'POST':
        wrestler['name'] = request.form['name']
        wrestler['signature_move'] = request.form['signature_move']
        return redirect(url_for('index'))

    return render_template('update.html', wrestler=wrestler)

# Delete a wrestler
@app.route('/delete/<int:wrestler_id>')
def delete(wrestler_id):
    global wrestlers
    wrestlers = [w for w in wrestlers if w['id'] != wrestler_id]
    return redirect(url_for('index'))

if __name__ == '__main__':
    app.run(debug=True)
