from flask import Flask, render_template, request, redirect, url_for
from pymongo import MongoClient
from bson.objectid import ObjectId

app = Flask(__name__)

# MongoDB connection
client = MongoClient("mongodb+srv://vasanthbups:bupathi1@wwe4ever.sfjyd.mongodb.net/?retryWrites=true&w=majority&appName=wwe4ever")  # Replace with your MongoDB URI
db = client.wrestling_db  # Database
wrestlers_collection = db["wrestlers"]  # Collection for wrestlers

@app.route('/')
def index():
    # Fetch all wrestlers from MongoDB
    wrestlers = wrestlers_collection.find()
    return render_template('index.html', wrestlers=wrestlers)

@app.route('/add', methods=['POST'])
def add_wrestler():
    # Get data from the form
    name = request.form.get('name')
    signature_move = request.form.get('signature_move')

    # Insert wrestler into the database
    wrestler = {
        'name': name,
        'signature_move': signature_move,
    }

    wrestlers_collection.insert_one(wrestler)
    return redirect(url_for('index'))

@app.route('/edit/<wrestler_id>', methods=['GET', 'POST'])
def edit_wrestler(wrestler_id):
    if request.method == 'POST':
        # Get updated data from the form
        name = request.form.get('name')
        signature_move = request.form.get('signature_move')

        # Update wrestler in the database
        wrestlers_collection.update_one(
            {'_id': ObjectId(wrestler_id)},
            {'$set': {'name': name, 'signature_move': signature_move, 'country': country}}
        )
        return redirect(url_for('index'))

    # Retrieve the wrestler data for editing
    wrestler = wrestlers_collection.find_one({'_id': ObjectId(wrestler_id)})
    return render_template('edit.html', wrestler=wrestler)

@app.route('/delete/<wrestler_id>', methods=['GET'])
def delete_wrestler(wrestler_id):
    # Delete wrestler from the database
    wrestlers_collection.delete_one({'_id': ObjectId(wrestler_id)})
    return redirect(url_for('index'))

if __name__ == '__main__':
    app.run(debug=True)
