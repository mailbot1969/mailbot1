from flask import Flask, jsonify, request

app = Flask(__name__)

# In-memory data structure to hold wrestler details
wrestlers = [
    {'id': 1, 'name': 'John Cena', 'signature_move': 'Attitude Adjustment'},
    {'id': 2, 'name': 'The Undertaker', 'signature_move': 'Tombstone Piledriver'},
    {'id': 3, 'name': 'Stone Cold Steve Austin', 'signature_move': 'Stone Cold Stunner'},
]

# Get all wrestlers
@app.route('/wrestlers', methods=['GET'])
def get_wrestlers():
    return jsonify(wrestlers)

# Get a specific wrestler
@app.route('/wrestlers/<int:wrestler_id>', methods=['GET'])
def get_wrestler(wrestler_id):
    wrestler = next((w for w in wrestlers if w['id'] == wrestler_id), None)
    if wrestler:
        return jsonify(wrestler)
    return jsonify({'error': 'Wrestler not found'}), 404

# Create a new wrestler
@app.route('/wrestlers', methods=['POST'])
def create_wrestler():
    data = request.json
    new_id = max(w['id'] for w in wrestlers) + 1 if wrestlers else 1
    new_wrestler = {'id': new_id, 'name': data['name'], 'signature_move': data['signature_move']}
    wrestlers.append(new_wrestler)
    return jsonify(new_wrestler), 201

# Update a wrestler
@app.route('/wrestlers/<int:wrestler_id>', methods=['PUT'])
def update_wrestler(wrestler_id):
    data = request.json
    wrestler = next((w for w in wrestlers if w['id'] == wrestler_id), None)
    if wrestler:
        wrestler['name'] = data['name']
        wrestler['signature_move'] = data['signature_move']
        return jsonify(wrestler)
    return jsonify({'error': 'Wrestler not found'}), 404

# Delete a wrestler
@app.route('/wrestlers/<int:wrestler_id>', methods=['DELETE'])
def delete_wrestler(wrestler_id):
    global wrestlers
    wrestler = next((w for w in wrestlers if w['id'] == wrestler_id), None)
    if wrestler:
        wrestlers = [w for w in wrestlers if w['id'] != wrestler_id]
        return jsonify({'message': 'Wrestler deleted'})
    return jsonify({'error': 'Wrestler not found'}), 404

if __name__ == '__main__':
    app.run(debug=True)
