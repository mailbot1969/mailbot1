from flask import Flask, render_template, request
import requests

app = Flask(__name__)

# Replace 'YOUR-API-KEY' with your actual API key
API_KEY = '87f45f5604585094028ac982'
BASE_URL = 'https://v6.exchangerate-api.com/v6'

@app.route('/', methods=['GET', 'POST'])
def index():
    conversion_result = None
    error = None

    if request.method == 'POST':
        from_currency = request.form.get('from_currency')
        to_currency = request.form.get('to_currency')
        amount = request.form.get('amount')

        if from_currency and to_currency and amount:
            try:
                url = f'{BASE_URL}/{API_KEY}/pair/{from_currency}/{to_currency}/{amount}'
                response = requests.get(url)
                data = response.json()

                if response.status_code == 200 and data['result'] == 'success':
                    conversion_result = {
                        'converted_amount': data['conversion_result'],
                        'rate': data['conversion_rate'],
                        'from_currency': from_currency,
                        'to_currency': to_currency,
                    }
                else:
                    error = 'Unable to fetch conversion data. Please try again.'
            except Exception as e:
                error = 'An error occurred. Please check your input and try again.'
        else:
            error = 'All fields are required.'

    return render_template('index.html', conversion_result=conversion_result, error=error)

if __name__ == '__main__':
    app.run(debug=True)
